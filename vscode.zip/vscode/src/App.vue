<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container>
      <Componetizar />
    </q-page-container>
  </q-layout>
</template>

<script setup>
import Componetizar from './components/Componetizar.vue'
</script>

<style>
</style>
